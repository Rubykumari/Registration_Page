import React, { Component } from 'react';
import PhoneInput from 'react-phone-number-input/input';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import AppBar from 'material-ui/AppBar';
import TextField from 'material-ui/TextField';
import RaisedButton from 'material-ui/RaisedButton';

export class FormUserDetails extends Component {
    continue = e =>{
        e.preventDefault();
		this.props.handleSubmit(e);
        this.props.nextStep();
    }

    render() {
        const {handleChange} = this.props;

        return (
            <MuiThemeProvider>
                <center>
                    <AppBar title='Registration'/>
                    <TextField
                      hintText='Enter your first name'
                      floatingLabelText = 'User first name'
                      onChange = {handleChange('userName')}
                    />
                    <br/>
                    <TextField
                      hintText='Enter your last name'
                      floatingLabelText = 'User last name'
                      onChange = {handleChange('userName')}
                    />
                    <br/>
                    <TextField
                      hintText='Enter your email_id'
                      floatingLabelText = 'Email_id'
                      onChange = {handleChange('email')}
                    //   defaultValue = {values.email}
                    />
                    <br/>
                    <TextField
                      hintText='Enter your password'
                      floatingLabelText = 'Password'
                      onChange = {handleChange('password')}
                    />
                    <br/>
                    <Input
                        value={value}
                        onChange={setValue}/>
                    <RaisedButton
                       label='Submit'
                       primary = {true}
                       onClick = {this.continue}
                    />
                </center>
            </MuiThemeProvider>
        );
    }

     styles = {
         button :{
             margin : 15
         }
    }
}

export default FormUserDetails;
