import React, { Component } from 'react'
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import AppBar from 'material-ui/AppBar';
import RaisedButton from 'material-ui/RaisedButton';


export default class Success extends Component {
  back = e =>{
    e.preventDefault();
    this.props.firstStep();
}
  render() {
  const {data} = this.props;
  //  Javascript code 
  
        return (
            <MuiThemeProvider>
                <center>
                    <AppBar title='User List'/>
                <div>
                <table align="center">
                  <thead>
                    <tr>
                        <th>Username</th>
                        <th>EmailID</th>
                        <th>Password</th>
                    </tr>
                  </thead>

                  <tbody>
                  {data.map((obj) => (
                  <tr>
                        <td>{obj.userName}</td>
                        <td>{obj.email}</td>
                        <td>{obj.password}</td>
                    </tr>
                  ))}
            </tbody>
                  </table>
                  <RaisedButton 
                    label='Registration Page'
                    primary = {true}
                    onClick = {this.back}/>
                </div>
                </center>

                </MuiThemeProvider>
        )
    }
}