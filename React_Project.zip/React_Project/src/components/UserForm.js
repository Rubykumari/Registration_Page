import React, { Component } from 'react'
import FormUserDetails from './FormUserDetails';
import Confirm from './Confirm';
import Success from './Success';

export default class UserForm extends Component {
    state={
        step : 1,
       userName :'',
       email : '',
       password : '',
	   data: []
    }
    // proceed to next step
    nextStep = ()=>{
        const {step} = this.state;
        this.setState({
            step : step+1
        })
    }
//  got back to registration page 
    firstStep = ()=>{
        const {step} = this.state;
        this.setState({
            step : step-2
        })
    }
    // Handle field change 
    handleChange = input => e =>{
     this.setState({[input]:e.target.value});	 
    }
	
    handleSubmit = (event) => {
        debugger;
		event.preventDefault();
		if(this.state.userName !== '' && this.state.email !== '' && this.state.password !== ''){
            var obj = {};
            obj.userName = this.state.userName;
            obj.email = this.state.email;
            obj.password = this.state.password;
            this.setState({data:[...this.state.data,obj]});
     }

}



    render() {
        const {step} = this.state;
        const {userName,email,password} = this.state;
        const values = {userName,email,password}
        switch(step){
          case 1:
              return (
                  <FormUserDetails 
                     nextStep = {this.nextStep}
                     handleChange = {this.handleChange}
					 handleSubmit= {this.handleSubmit}
                     values = {values}
                  />
              );
          case 2 : 
          return (
            <Confirm
            nextStep = {this.nextStep}
            prevStep = {this.prevStep}
            addData= {this.addData}
            values = {values}
         />
          )  
          case 3 : 
          return (
            <Success
            values = {values}
            data = {this.state.data}
            firstStep = {this.firstStep}
            />
          )
              
          default:
              return <h1>Invalid Page</h1>
              
        }
    }
}

