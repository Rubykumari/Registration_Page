import React, { Component } from 'react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import AppBar from 'material-ui/AppBar';
import {List, ListItem} from 'material-ui/List';
import RaisedButton from 'material-ui/RaisedButton';

export class Confirm extends Component {

    continue = e =>{
        e.preventDefault();
        this.props.nextStep();
        
    }

    render() {
        const {values:{userName, email, password}} = this.props;

        return (
            <MuiThemeProvider>
               <center>
               <AppBar title='Dashboard'/>
                    <List>
                        <ListItem
                            primaryText="Full Name"
                            secondaryText={userName}
                        />
                        <ListItem
                            primaryText="Email"
                            secondaryText={email}
                        />
                        <ListItem
                            primaryText="Password"
                            secondaryText={password}
                        />

                    </List>
                    <RaisedButton
                       label='Next'
                       primary = {true}
                       onClick = {this.continue}
                    />
                  </center>
                </MuiThemeProvider>
            
        );
    }

     styles = {
         button :{
             margin : 15
         }
    }
}

export default Confirm;
